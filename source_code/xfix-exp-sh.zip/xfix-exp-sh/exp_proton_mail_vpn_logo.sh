python -u xfixrandom_uiautomator.py $1 $2 ./subject_apks/ProtonMail-Android-vpn_logo.apk res/layout/activity_onboarding.xml ImageView src drawable ch.protonmail.android vpn_logo proton_mail_vpn_logo
