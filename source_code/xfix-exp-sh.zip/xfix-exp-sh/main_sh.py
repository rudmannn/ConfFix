import os
import re

string1 = "if [ -z $1 ]\n" \
"then\n" \
"  echo \"Error, no input\"\n" \
"  exit\n" \
"elif [ -z $2 ]\n" \
"then\n" \
"  echo \"Error, no input\"\n" \
"  exit\n" \
"else\n"

string2 = "fi"

def findAllFile(str):

    if os.path.isdir(str):
        os.chdir(str)
        for i in os.listdir("."):
            findAllFile(i)
        os.chdir("..")

    elif str.endswith(".sh"):
        # print(str)
        parseFile(str)

def parseFile(file):
    with open(file) as f:
        arrs = f.readlines()
        # cmd = arrs[0].replace("/ssddata1/hhuangas/conffix-python-test/image_differences", ".").replace("-1.txt", ".txt")
        # k = re.match(r'(.*)emulator-\d\d\d\d(.*) \| tee(.*)', cmd)
        # print(k.group(1) + "$1 $2" + k.group(2))
        if "hh" in arrs[0] or "hua" in arrs[0]:
            print(file)
            print(arrs[0])

    # with open(file, "w") as f:
    #     # f.write(string1)
    #     f.write(k.group(1) + "$1 $2"+k.group(2)+"\n")
    #     # f.write(string2)

if __name__ == '__main__':
    findAllFile(".")




# s = "  python -u xmlutilrandom_testcase.py emulator-5560 ./subject_apks/FairEmail-tvPrivacy.apk res/layout-v22/fragment_setup.xml TextView drawableTint color ./subject_apks/test_apks/FairEmail-androidTest.apk ConfFixTest#tvSyncStopped eu.faircode.email.debug.test eu.faircode.email.debug tvSyncStopped | tee ./conffix-output/FairEmail-tvSyncStopped.txt"
#
# k = re.match(r'(.*)emulator-\d\d\d\d(.*) \| tee(.*)', s)
#
# print(k.group(1) + "$1 $2 "+k.group(2))
#

