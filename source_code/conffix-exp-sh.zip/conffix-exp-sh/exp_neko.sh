python xmlutilrandom_uiautomator.py $1 $2 ./subject_apks/neko__81418a7.apk res/layout/reader_activity.xml LayoutParam layout_height dimension eu.kanade.tachiyomi.debug page_seekbar neko__81418a7
