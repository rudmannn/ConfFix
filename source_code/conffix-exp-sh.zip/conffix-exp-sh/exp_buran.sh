python -u xmlutilrandom_uiautomator.py $1 $2 ./subject_apks/Buran.apk res/layout-v22/gemtext_text.xml TextView lineHeight dimension corewala.gemini.buran gemtext_text_textview buran
